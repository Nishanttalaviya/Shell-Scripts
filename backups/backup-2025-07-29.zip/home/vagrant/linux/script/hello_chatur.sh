#!/bin/bash

echo "hello word" 

mkdir -p rancho

echo "hello word" > file.txt

