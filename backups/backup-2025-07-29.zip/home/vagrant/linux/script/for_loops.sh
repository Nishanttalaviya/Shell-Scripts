#!/bin/bash

<<info

loops: anything that you want o repeat again anf again based on condition
for loops conditions

info

for ((num=1 ; num<=10 ; num++ ))
do
	echo "$num"
	echo "hello"

done

for ((i=1 ; i<=5 ; i++))
do 
	echo "create user $i"

done

